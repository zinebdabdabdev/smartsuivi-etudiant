CREATE DATABASE smartsuivi_db;

USE smartsuivi_db;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role VARCHAR(20) DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE student_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    study_hours FLOAT,
    absences INT,
    average_grade FLOAT,
    sleep_hours FLOAT,
    participation FLOAT,
    
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE predictions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    prediction VARCHAR(50),
    probability FLOAT,
    recommendation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id)
);
