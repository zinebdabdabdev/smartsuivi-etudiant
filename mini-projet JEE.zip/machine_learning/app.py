from flask import Flask, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__)

modele = joblib.load(
    "model/modele_prediction.pkl"
)

@app.route("/predict", methods=["POST"])
def predict():

    data = request.get_json()

    df = pd.DataFrame([{
        "TempsEtude": float(data["TempsEtude"]),
        "Absences": int(data["Absences"]),
        "MoyenneSemestre": float(data["MoyenneSemestre"]),
        "Sommeil": float(data["Sommeil"]),
        "Participation": float(data["Participation"]),
        "UtilisationTelephone": float(data["UtilisationTelephone"])
    }])

    prediction = modele.predict(df)

    return jsonify({
        "niveau": prediction[0]
    })

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )