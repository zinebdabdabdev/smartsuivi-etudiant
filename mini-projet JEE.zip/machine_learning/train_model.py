import pandas as pd

from sklearn.model_selection import train_test_split

from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

import joblib

# ==========================
# CHARGEMENT DATASET
# ==========================

data = pd.read_csv(
    "dataset/student_profile_dataset.csv"
)

print("\n=== APERCU DATASET ===")
print(data.head())

# ==========================
# SUPPRESSION VALEURS VIDES
# ==========================

data = data.dropna()

# ==========================
# VARIABLE CIBLE
# ==========================

y = data["Niveau"]

# ==========================
# VARIABLES EXPLICATIVES
# ==========================

X = data.drop(
    ["Niveau"],
    axis=1
)

print("\nDimensions X :", X.shape)

print("Dimensions y :", y.shape)

# ==========================
# DIVISION TRAIN / TEST
# ==========================

X_train, X_test, y_train, y_test = train_test_split(

    X,

    y,

    test_size=0.2,

    random_state=42
)

print("\nTrain :", len(X_train))

print("Test :", len(X_test))

# ==========================
# RANDOM FOREST
# ==========================

modele = RandomForestClassifier(

    n_estimators=100,

    random_state=42
)

modele.fit(
    X_train,
    y_train
)

print("\nModèle entraîné.")

# ==========================
# PREDICTIONS
# ==========================

prediction = modele.predict(
    X_test
)

# ==========================
# EVALUATION
# ==========================

print("\nAccuracy :")

print(
    accuracy_score(
        y_test,
        prediction
    )
)

print("\nPrecision :")

print(
    precision_score(
        y_test,
        prediction,
        average="weighted"
    )
)

print("\nRecall :")

print(
    recall_score(
        y_test,
        prediction,
        average="weighted"
    )
)

print("\nF1 Score :")

print(
    f1_score(
        y_test,
        prediction,
        average="weighted"
    )
)

print("\nMatrice de confusion :")

print(
    confusion_matrix(
        y_test,
        prediction
    )
)

# ==========================
# SAUVEGARDE MODELE
# ==========================

joblib.dump(

    modele,

    "model/modele_prediction.pkl"
)

print(
    "\nModèle sauvegardé avec succès."
)