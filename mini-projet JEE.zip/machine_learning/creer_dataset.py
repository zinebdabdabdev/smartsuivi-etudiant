import pandas as pd

data = pd.read_csv(
    "dataset/StudentPerformanceFactors.csv"
)

nouveau_dataset = pd.DataFrame()

nouveau_dataset["TempsEtude"] = data["Hours_Studied"]

nouveau_dataset["Absences"] = 100 - data["Attendance"]

nouveau_dataset["MoyenneSemestre"] = (
    data["Previous_Scores"] / 5
)

nouveau_dataset["Sommeil"] = (
    data["Sleep_Hours"]
)

nouveau_dataset["Participation"] = (
    data["Motivation_Level"].map({
        "Low": 3,
        "Medium": 6,
        "High": 9
    })
)

nouveau_dataset["UtilisationTelephone"] = (
    10 - data["Physical_Activity"]
)

def classifier(score):

    if score < 60:
        return "A_risque"

    elif score < 75:
        return "Moyen"

    else:
        return "Excellent"

nouveau_dataset["Niveau"] = (
    data["Exam_Score"].apply(classifier)
)

nouveau_dataset.to_csv(
    "dataset/student_profile_dataset.csv",
    index=False
)

print("Dataset créé avec succès")